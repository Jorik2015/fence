package org.one2team.highcharts.shared;

public interface Jsonify {

	String toJson ();
}
