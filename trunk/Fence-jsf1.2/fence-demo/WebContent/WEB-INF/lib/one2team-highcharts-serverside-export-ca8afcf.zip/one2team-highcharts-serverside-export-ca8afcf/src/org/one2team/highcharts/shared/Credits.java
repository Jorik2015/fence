package org.one2team.highcharts.shared;

public interface Credits {

	Credits setEnabled(boolean b);

}
