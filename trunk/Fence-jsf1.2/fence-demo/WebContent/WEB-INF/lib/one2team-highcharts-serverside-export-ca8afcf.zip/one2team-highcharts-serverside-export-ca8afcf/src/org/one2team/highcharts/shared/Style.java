package org.one2team.highcharts.shared;

public interface Style {
  
  Style setProperty(String property, String value);
  
  String getProperty(String property);
}
