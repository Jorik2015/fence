package org.one2team.highcharts.shared.dynamic;

public interface Element {
  
  void attr (String property, String value);
  
  String ATTR_FILL = "fill";
  
  String ATTR_STROKE = "stroke";
  
}
